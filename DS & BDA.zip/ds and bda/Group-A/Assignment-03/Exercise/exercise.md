## Exercise: Median, Mean, Percentile

Use this air bnb new york city [data set](https://www.kaggle.com/dgomonov/new-york-city-airbnb-open-data/data) and remove outliers using percentile based on price per night for a given apartment/home. You can use suitable upper and lower limits on percentile based on your intuition. Your goal is to come up with new pandas dataframe that doesn't have the outliers present in it.

[Solution](https://github.com/codebasics/math-for-machine-learning/blob/main/4_mean_percentile/Exercise/percentile_exercise_solution.ipynb)